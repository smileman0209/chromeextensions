/* eslint-disable no-unused-vars */
const CERBERUS_URL = 'https://api2.wejustsocial.com'
