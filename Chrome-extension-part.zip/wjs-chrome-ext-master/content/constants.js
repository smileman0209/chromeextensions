/* eslint-disable no-unused-vars */
const SLEEP_TIME = 3000
const SLEEP_ACTION = 2000
const LIKE_PERCENTAGE = 60
const FOLLOW_PERCENTAGE = 60
