#!/bin/sh
service mongodb start
service redis-server start
