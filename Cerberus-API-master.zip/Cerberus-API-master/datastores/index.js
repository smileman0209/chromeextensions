/** Dataaccess shortcut */
module.exports = require('./dataaccess')
