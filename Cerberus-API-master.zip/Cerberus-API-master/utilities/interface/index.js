module.exports = class UtilityInterface {
	/**
	 * @constructor
	 */
	constructor() {
		throw new Error('Can\'t instantiate an utility class')
	}
}
